# 📋 PRD — MGL Fontanería y Servicios

**Versión:** 1.0  
**Fecha:** 29 de julio de 2026  
**Objetivo:** Definir los requisitos funcionales y de diseño para la web de MGL Fontanería y Servicios

---

## 1. Resumen Ejecutivo

MGL Fontanería y Servicios es una empresa de reparación y mantenimiento hidráulico con cobertura en la comarca de El Palmar (Murcia). La web tiene dos objetivos principales: **generar leads** (solicitudes de presupuesto/contacto) e **informar sobre servicios** ofrecidos. El público es generalista (particulares, comunidades, pequeños comercios). Diseño **mobile-first**.

---

## 2. Información de la Empresa

| Dato | Valor |
|------|-------|
| **Nombre** | MGL Fontanería y Servicios |
| **Persona de Contacto** | Manolo García Luján |
| **Teléfono** | 657 37 46 96 |
| **Email** | mglfys@gmail.com |
| **Dirección** | Avenida del Progreso Nº 6, Esc. 11, 3-4, 30120 Murcia |
| **Zona de Cobertura** | Comarca de El Palmar (Murcia y pueblos cercanos) |
| **Disponibilidad** | 24/7 (emergencias) |

---

## 3. Objetivos de la Web

### Primarios
1. **Generar leads** — Captar solicitudes de presupuesto y contactos directos
2. **Informar** — Dar a conocer servicios y capacidades de la empresa

### Secundarios
- Mejorar presencia digital frente a competencia (ej: Electrobombas Joyma)
- Establecer confianza mediante profesionalismo y experiencia
- Facilitar contacto multicanal (teléfono, email, WhatsApp, formulario)

---

## 4. Público Objetivo

**Segmentación:** Sin segmentación específica. Público generalista.

**Perfiles:**
- Particulares con problemas de fontanería en casa (fugas, grifería, calderas)
- Administradores de comunidades de vecinos
- Pequeños comercios y tiendas con problemas hidráulicos
- Empresas locales

**Necesidad principal:** Resolver problema rápido, confiable y a buen precio.

---

## 5. Propuesta de Valor / Diferenciadores

### Core Value Propositions
1. **Rapidez** — "Reparamos en X horas" (especificar tiempo exacto en web)
2. **Profesionalismo/Experiencia** — Años de trayectoria, técnicos certificados
3. **Garantía** — Trabajos garantizados, sin sorpresas ocultas

**Ventaja competitiva vs. Joyma:** MGL ofrece fontanería general + servicios versátiles, no solo electrobombas especializadas.

---

## 6. Servicios Principales

1. Reparación de fugas
2. Instalación de grifería
3. Mantenimiento de calderas
4. Soluciones efectivas para el tratamiento de agua
5. Localizador de fugas de agua con gas traza
6. *[Otros servicios que hayas enumerado]*

**Nota:** Completar si falta alguno.

---

## 7. Canales de Contacto y Conversión

### Modelo de Conversión
**Presupuesto a pedido** — Cliente solicita información, MGL envía presupuesto personalizado.

### Canales Activos
- ☎️ **Teléfono:** 657 37 46 96 (visible y clickable)
- 📧 **Email:** mglfys@gmail.com (visible y clickable)
- 📱 **WhatsApp:** [Incluir número, presumiblemente el mismo]
- 📝 **Formulario web:** "Solicitar presupuesto" / "Contactar"

**Placement:** Múltiples puntos de contacto (header, hero, footer, sidebar, CTA en tarjetas de servicios).

---

## 8. Estructura de la Web (Sitemap)

```
Homepage (Hero + Servicios + CTA)
├── Servicios (Página de servicios con detalle)
├── Sobre Nosotros (Trayectoria, certificaciones, equipo)
├── Contacto (Formulario + mapa + info de contacto)
├── FAQ / Blog (Opcional: consejos, preguntas frecuentes)
└── Política de Privacidad / Legal (Requerido)
```

---

## 9. Requisitos Funcionales

### Homepage
- [ ] Hero section con CTA principal ("Solicitar Presupuesto" / "Llamar Ahora")
- [ ] Breve descripción: "¿Problema de fontanería? Reparamos en X horas. Disponibles 24/7."
- [ ] Sección de servicios principales (4-6 tarjetas con iconos)
- [ ] CTA secundaria: "Ver todos los servicios"
- [ ] Sección de por qué elegir MGL (rapidez, experiencia, garantía)
- [ ] Testimonios/reseñas (si existen)
- [ ] Formulario de contacto rápido o CTA a página de contacto
- [ ] Footer con info de contacto completa

### Página de Servicios
- [ ] Listado detallado de servicios (8-10)
- [ ] Descripción breve de cada uno (50-100 palabras)
- [ ] Iconos o imágenes representativas
- [ ] CTA por servicio: "Solicitar presupuesto para este servicio"

### Página de Contacto
- [ ] Formulario completo (nombre, teléfono, email, descripción del problema, servicio)
- [ ] Mapa de ubicación (Google Maps)
- [ ] Info de contacto en texto (teléfono, email, dirección)
- [ ] Horarios de atención
- [ ] Enlaces a WhatsApp

### Página "Sobre Nosotros"
- [ ] Historia breve de la empresa
- [ ] Certificaciones y experiencia
- [ ] Foto/presentación del equipo (si disponible)
- [ ] Por qué confiar en MGL

### Legal
- [ ] Política de Privacidad
- [ ] Aviso Legal
- [ ] Política de Cookies (si se usan)

---

## 10. Requisitos de Diseño (Brand Book Integration)

**Paleta de Colores:**
- Azul Profesional `#0066CC` — Headers, CTAs primarias
- Negro Técnico `#1A1A1A` — Textos principales
- Blanco `#FFFFFF` — Fondos
- Azul Cielo `#00A8FF` — Acentos, hover
- Verde `#28A745` — CTAs de éxito ("Contactar", "Solicitar")

**Tipografía:**
- Headers: Poppins Bold (48px H1, 32px H2, 24px H3)
- Body: Inter Regular (16px, line-height 1.6)
- CTAs: Poppins SemiBold, uppercase, 16px

**Estilo Fotográfico:**
- Fotos de trabajo real (plomeros reparando, antes/después)
- Ambientes domésticos reales
- Sin stock photos genéricos
- Iluminación clara, enfoque en proceso

**Tono de Voz:**
- Confiable: "Resolvemos tu problema"
- Urgente pero calmado: "Disponibles 24/7"
- Cercano: Tú en CTAs, usted en descripciones

---

## 11. Requisitos Técnicos

### Plataforma
- [ ] Sitio web responsive (mobile-first)
- [ ] Compatible con Chrome, Firefox, Safari, Edge
- [ ] Velocidad de carga < 3 segundos
- [ ] SEO básico (meta tags, URLs semánticas, sitemap.xml)

### Funcionalidades
- [ ] Formulario de contacto funcional (enviar a email)
- [ ] Integración con Google Maps (ubicación)
- [ ] Botón WhatsApp clickable
- [ ] Enlaces de teléfono clickables (tel:)
- [ ] Analytics básico (Google Analytics)

### Hosting/Dominio
- [ ] Dominio personalizado (ej: www.mglfontaneria.es)
- [ ] Hosting fiable
- [ ] SSL certificate (HTTPS)
- [ ] Backups automáticos

---

## 12. Prioridades de Desarrollo

### Fase 1 (MVP — Mínimo Viable)
- [ ] Homepage con hero + servicios + CTA
- [ ] Página de contacto con formulario
- [ ] Página de servicios
- [ ] Footer con info

### Fase 2 (Mejoras)
- [ ] Página "Sobre Nosotros"
- [ ] Testimonios/reseñas
- [ ] FAQ o blog
- [ ] Optimización SEO

### Fase 3 (Opcional)
- [ ] Sistema de citas online
- [ ] Chat en vivo
- [ ] Galería de proyectos

---

## 13. Métricas de Éxito

- [ ] **Leads:** X presupuestos solicitados al mes
- [ ] **Tráfico:** X visitas mensuales
- [ ] **Conversión:** X% de visitantes → solicitud de presupuesto
- [ ] **Mobile:** X% de tráfico desde móvil
- [ ] **Posicionamiento:** Aparecer en top 3 de Google para "fontanero El Palmar" / "fontanería Murcia"

---

## 14. Calendario Aproximado

- **Semana 1:** Diseño wireframes + aprobación
- **Semana 2-3:** Desarrollo HTML/CSS + contenido
- **Semana 4:** Testing, ajustes, optimización
- **Semana 5:** Deploy y puesta en vivo

---

## 15. Notas y Consideraciones

- **Contenido visual:** Falta contenido fotográfico. Prioridad: fotografiar trabajos reales o buscar imágenes de calidad en Unsplash/Pexels.
- **SEO local:** Registrar en Google My Business para aparecer en búsquedas locales.
- **Competencia:** Analizar ventajas frente a Electrobombas Joyma (menos genérico, más fontanería general).
- **Mobile-first:** Toda la UX diseñada primero en móvil, luego adaptada a escritorio.
- **CTA clara:** Cada sección debe tener un call-to-action evidente (teléfono, formulario, WhatsApp).

---

## 16. Próximos Pasos

1. ✅ Validar este PRD con Manolo García
2. ⏳ Preparar contenido: textos de servicios, descripciones, imágenes
3. ⏳ Crear wireframes de cada página
4. ⏳ Iniciar desarrollo HTML/CSS
5. ⏳ Testing en móvil y escritorio
6. ⏳ Deploy

---

**Aprobado por:** [Pendiente]  
**Última actualización:** 29 de julio de 2026
