# 🔧 MGL Fontanería y Servicios — Brand Book

## 1. Identidad Visual

MGL es una empresa de fontanería confiable, profesional y accesible. La identidad visual refleja competencia técnica, seguridad y disponibilidad.

---

## 2. Paleta de Colores

### Colores Primarios
- **Azul Profesional** `#0066CC` — Confianza, fluidez, agua. Uso: headers, CTAs, elementos principales.
- **Negro Técnico** `#1A1A1A` — Profesionalismo, solidez. Uso: textos principales, contornos.
- **Blanco Limpio** `#FFFFFF` — Claridad, higiene. Uso: fondos, espacios.

### Colores Secundarios
- **Azul Cielo** `#00A8FF` — Dinamismo, energía. Uso: acentos, hover states.
- **Gris Profesional** `#4A4A4A` — Textos secundarios, subtítulos.
- **Verde Agua** `#1EBF91` — Confianza en calidad (opcional, para certifications/garantías).

### Colores de Acción
- **Verde Éxito** `#28A745` — "Problema resuelto", disponibilidad.
- **Naranja Alerta** `#FF9500` — Urgencia, emergencias (sin alarmar).
- **Rojo Crítico** `#DC3545` — Solo para errores o situaciones críticas.

### Ejemplo de Gradiente
Azul Profesional → Azul Cielo para fondos de secciones clave (llama, confianza progresiva).

---

## 3. Tipografía

### Familia Principal: Sans-Serif Moderno
**Fuente:** Inter, Roboto o Poppins (Google Fonts — libre, profesional, legible)

- **H1 (Títulos principales):** Poppins Bold, 48px, tracking +0.5px
- **H2 (Subtítulos):** Poppins SemiBold, 32px, tracking +0.3px
- **H3 (Secciones):** Poppins Medium, 24px
- **Cuerpo (Body):** Inter Regular, 16px, line-height 1.6
- **Pequeño (Small):** Inter Regular, 14px
- **CTA Buttons:** Poppins SemiBold, 16px, uppercase con tracking +1px

### Uso Tipográfico
- Títulos con peso bold para autoridad.
- Cuerpo con línea ancha (1.6) para legibilidad en móvil.
- Letras capitales solo en botones y pequeñas labels.

---

## 4. Tono y Voz

### Principios
- **Confiable:** Lenguaje claro, sin jerga innecesaria. "Resolvemos tu problema" no "optimizamos tu infraestructura hídrica".
- **Profesional:** Formales pero cercanos. Usted en descripciones; tú en CTA y consejos.
- **Urgente pero calmado:** Transmitir disponibilidad sin pánico. "Emergencia 24/7" no "¡¡¡AYUDA!!!".
- **Técnico accesible:** Explicamos soluciones sin condescendencia.

### Ejemplos de Messaging
- ✅ "Reparamos cualquier fuga en menos de 2 horas."
- ✅ "¿Tubería rota? Llamanos. Resolvemos ya."
- ❌ "Servicios de fontanería premium de alta tecnología."

---

## 5. Estilo Fotográfico

### Orientación Visual
1. **Fotografías de trabajo real** — Plomeros en acción, herramientas, reparaciones completadas.
   - Iluminación clara, natural.
   - Enfoque en manos/proceso (no tanto en caras, para evitar necesidad de modelos).
   - Antes/después de reparaciones (fugas reparadas, tuberías limpias).

2. **Ambientes domésticos** — Baños, cocinas, jardines con problemas resueltos.
   - Planos de viviendas modernas y accesibles.
   - Usuarios satisfechos (opcional: testimonios visuales con fotos discretas).

3. **Iconografía técnica** — Vectores simples reflejando el logo (tuberías, gotas, herramientas).
   - Estilo flat o isométrico (no 3D, muy corporativo).
   - Colores: Azul primario, azul cielo, grises.

### Restricciones
- ❌ Fotos de stock genéricas ("ejecutivos sonriendo en reuniones").
- ❌ Imágenes muy clinicalistas o esterilizadas.
- ❌ Mucha saturación de color; mantén neutralidad en fondos.

### Recomendación
Prioriza fotografía original de tu equipo trabajando. Si no tienes, busca en Unsplash/Pexels: plomería, reparaciones, herramientas. Luego aplica color grading azul-gris.

---

## 6. Componentes Visuales

### Botones
- **Primary (CTA):** Azul Profesional (`#0066CC`), texto blanco, Poppins Bold, padding 14px 32px, border-radius 6px.
- **Secondary:** Bordes azul, fondo transparente, mismo textos.
- **Hover:** Azul Cielo (`#00A8FF`), sombra suave.

### Tarjetas de Servicios
- Fondo blanco, sombra discreta (0 2px 8px rgba(0,0,0,0.1)).
- Borde superior grueso (4px) en Azul Profesional.
- Iconos vectoriales (tuberías, grifos, etc.) en Azul Cielo.

### Separadores y Líneas
- Color: Gris Profesional (`#4A4A4A`) con opacidad 20%.
- Grosor: 1-2px.

### Llamadas a la Acción
- Fondos en verde (`#28A745`) para "Contactar", "Solicitar Presupuesto".
- Texto mayúscula, bold, con flecha → indicando acción.

---

## 7. Aplicaciones Prácticas

### Homepage Hero
- Fondo: Gradiente Azul Profesional → Azul Cielo (diagonal, sutil).
- Imagen de fondo: Plomero reparando una fuga con luz natural, desaturada 20%.
- Overlay: Negro semitransparente (30%) para legibilidad de texto.
- Titular: "Reparamos tu fontanería. Disponibles 24/7."

### Sección de Servicios
- 3-4 tarjetas con borde azul superior.
- Iconos vectoriales (grifo, tubería, calefacción).
- Descripción corta, CTA "Más info" en botón secundario.

### Formulario de Contacto
- Inputs con borde gris claro, focus azul.
- Botón de envío: Verde y mayúscula "SOLICITAR SERVICIO".

### Footer
- Fondo Azul Profesional oscurecido (`#004499`).
- Texto blanco, info de contacto clara.
- Logo en versión blanca.

---

## 8. Resumen Ejecutivo

| Elemento | Definición |
|----------|-----------|
| **Paleta** | Azul Profesional + Negro + Blanco; secundarios: Azul Cielo, Verde |
| **Tipografía** | Inter (body) + Poppins (headers), sans-serif moderno |
| **Tono** | Confiable, profesional, urgente pero calmado |
| **Fotos** | Trabajo real, ambientes domésticos, antes/después, sin stock genérico |
| **Estilo** | Limpio, técnico pero accesible, enfoque en soluciones |

---

## 9. Próximos Pasos

1. Adaptar este brand book a tu sitio web.
2. Crear una guía visual con ejemplos de cada componente.
3. Asegurar consistencia en todas las secciones.
4. Validar con clientes (test A/B si es posible).
