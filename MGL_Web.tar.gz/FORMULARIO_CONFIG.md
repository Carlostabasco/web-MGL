# 📧 Configuración del Formulario de Contacto - MGL

## Estado Actual
El formulario está configurado con **Formspree**, un servicio gratuito que recibe los emails sin necesidad de servidor.

## ¿Cómo funciona?

1. Usuario rellena el formulario en la web
2. Formspree recibe los datos
3. **Email automático a `mglfys@gmail.com`**
4. Usuario ve mensaje de confirmación

---

## 🔧 Pasos para Activar (UNA SOLA VEZ)

### Paso 1: Ir a Formspree
1. Abre: **https://formspree.io**
2. Regístrate con tu email (`mglfys@gmail.com`)

### Paso 2: Crear un nuevo formulario
1. Haz clic en **"New Form"**
2. Dale un nombre: `"MGL Contacto"`
3. Selecciona email: `mglfys@gmail.com`
4. Formspree te dará un **ID de formulario** (ej: `mjkqnodj`)

### Paso 3: Reemplazar el ID en el HTML
En el archivo `index.html`, busca esta línea:
```html
<form id="contactForm" action="https://formspree.io/f/mjkqnodj" method="POST">
```

Reemplaza `mjkqnodj` por tu ID real de Formspree.

### Paso 4: Verificar (Formspree te enviará un email)
Formspree te enviará un email de verificación. Haz clic en el enlace para confirmar.

---

## ✅ Listo

Una vez verificado:
- ✅ Los usuarios pueden enviar solicitudes desde la web
- ✅ Recibes emails en `mglfys@gmail.com` automáticamente
- ✅ El formulario muestra mensaje de confirmación
- ✅ **Gratis y sin servidor**

---

## 📝 Datos que recibirás en cada email

- **Nombre**: Nombre del cliente
- **Teléfono**: Teléfono de contacto
- **Email**: Email del cliente (para responder)
- **Servicio Solicitado**: Qué servicio quieren
- **Descripción del Problema**: Detalles del problema

---

## 🆘 Si hay problemas

### El formulario no envía
- Verifica que has confirmado el email de Formspree
- Asegúrate que el ID del formulario es correcto
- Prueba desde incógnito (sin caché)

### No recibo emails
- Revisa spam/correo no deseado
- Verifica que `mglfys@gmail.com` es correcto
- Intenta desde una red diferente

---

## 🚀 Alternativas (si quieres más opciones)

### EmailJS (más robusto)
- Requiere cuenta gratuita
- Más control sobre emails
- Documentación: https://www.emailjs.com/

### Backend propio (si subes a hosting)
- Usar PHP, Node.js, etc.
- Mayor control total
- Más complicado de configurar

---

## 📋 Resumen

**Formspree es lo más simple:** Configurar en 5 minutos, gratis, sin servidor, sin mantenimiento.

¿Necesitas ayuda con la configuración? Avísame.
